﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Results
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Results))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TXTSHITEscore = New System.Windows.Forms.Label()
        Me.Arrow150 = New System.Windows.Forms.PictureBox()
        Me.Arrow125 = New System.Windows.Forms.PictureBox()
        Me.Arrow75 = New System.Windows.Forms.PictureBox()
        Me.Arrow25 = New System.Windows.Forms.PictureBox()
        Me.Arrow0 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Arrow150, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Arrow125, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Arrow75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Arrow25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Arrow0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(524, 199)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(279, 258)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Papyrus", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(270, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(269, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Your score for the S.H.I.T.E test was: "
        '
        'TXTSHITEscore
        '
        Me.TXTSHITEscore.AutoSize = True
        Me.TXTSHITEscore.Location = New System.Drawing.Point(530, 45)
        Me.TXTSHITEscore.Name = "TXTSHITEscore"
        Me.TXTSHITEscore.Size = New System.Drawing.Size(44, 13)
        Me.TXTSHITEscore.TabIndex = 2
        Me.TXTSHITEscore.Text = "SCORE"
        '
        'Arrow150
        '
        Me.Arrow150.BackColor = System.Drawing.Color.Transparent
        Me.Arrow150.Image = CType(resources.GetObject("Arrow150.Image"), System.Drawing.Image)
        Me.Arrow150.Location = New System.Drawing.Point(490, 153)
        Me.Arrow150.Name = "Arrow150"
        Me.Arrow150.Size = New System.Drawing.Size(140, 113)
        Me.Arrow150.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Arrow150.TabIndex = 3
        Me.Arrow150.TabStop = False
        '
        'Arrow125
        '
        Me.Arrow125.BackColor = System.Drawing.Color.Transparent
        Me.Arrow125.Image = CType(resources.GetObject("Arrow125.Image"), System.Drawing.Image)
        Me.Arrow125.Location = New System.Drawing.Point(463, 209)
        Me.Arrow125.Name = "Arrow125"
        Me.Arrow125.Size = New System.Drawing.Size(140, 113)
        Me.Arrow125.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Arrow125.TabIndex = 4
        Me.Arrow125.TabStop = False
        '
        'Arrow75
        '
        Me.Arrow75.BackColor = System.Drawing.Color.Transparent
        Me.Arrow75.Image = CType(resources.GetObject("Arrow75.Image"), System.Drawing.Image)
        Me.Arrow75.Location = New System.Drawing.Point(443, 250)
        Me.Arrow75.Name = "Arrow75"
        Me.Arrow75.Size = New System.Drawing.Size(140, 113)
        Me.Arrow75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Arrow75.TabIndex = 5
        Me.Arrow75.TabStop = False
        '
        'Arrow25
        '
        Me.Arrow25.BackColor = System.Drawing.Color.Transparent
        Me.Arrow25.Image = CType(resources.GetObject("Arrow25.Image"), System.Drawing.Image)
        Me.Arrow25.Location = New System.Drawing.Point(420, 290)
        Me.Arrow25.Name = "Arrow25"
        Me.Arrow25.Size = New System.Drawing.Size(140, 113)
        Me.Arrow25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Arrow25.TabIndex = 6
        Me.Arrow25.TabStop = False
        '
        'Arrow0
        '
        Me.Arrow0.BackColor = System.Drawing.Color.Transparent
        Me.Arrow0.Image = CType(resources.GetObject("Arrow0.Image"), System.Drawing.Image)
        Me.Arrow0.Location = New System.Drawing.Point(399, 328)
        Me.Arrow0.Name = "Arrow0"
        Me.Arrow0.Size = New System.Drawing.Size(140, 113)
        Me.Arrow0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Arrow0.TabIndex = 7
        Me.Arrow0.TabStop = False
        '
        'Results
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Arrow0)
        Me.Controls.Add(Me.Arrow25)
        Me.Controls.Add(Me.Arrow75)
        Me.Controls.Add(Me.Arrow125)
        Me.Controls.Add(Me.Arrow150)
        Me.Controls.Add(Me.TXTSHITEscore)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Results"
        Me.Text = "Results"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Arrow150, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Arrow125, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Arrow75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Arrow25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Arrow0, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TXTSHITEscore As Label
    Friend WithEvents Arrow150 As PictureBox
    Friend WithEvents Arrow125 As PictureBox
    Friend WithEvents Arrow75 As PictureBox
    Friend WithEvents Arrow25 As PictureBox
    Friend WithEvents Arrow0 As PictureBox
End Class
