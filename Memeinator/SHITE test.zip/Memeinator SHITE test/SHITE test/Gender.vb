﻿Imports System.Data.SqlClient
Public Class Gender
    Private Sub CMDfemale_Click(sender As Object, e As EventArgs) Handles CMDfemale.Click
        FemaleTest.Show()
        Me.Hide()
    End Sub

    Private Sub CMDmale_Click(sender As Object, e As EventArgs) Handles CMDmale.Click
        MaleTest.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SHITEmenu.Show()
        Me.Close()
    End Sub

    Private Sub Gender_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class