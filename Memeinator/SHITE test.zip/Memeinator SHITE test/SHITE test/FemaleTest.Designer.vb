﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FemaleTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FemaleTest))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CBQ8no = New System.Windows.Forms.CheckBox()
        Me.CBQ8yes = New System.Windows.Forms.CheckBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.CmdClose = New System.Windows.Forms.Button()
        Me.CBQ7no = New System.Windows.Forms.CheckBox()
        Me.CBQ7yes = New System.Windows.Forms.CheckBox()
        Me.CBQ6no = New System.Windows.Forms.CheckBox()
        Me.CBQ6yes = New System.Windows.Forms.CheckBox()
        Me.CBQ5no = New System.Windows.Forms.CheckBox()
        Me.CBQ5yes = New System.Windows.Forms.CheckBox()
        Me.CBQ4no = New System.Windows.Forms.CheckBox()
        Me.CBQ4yes = New System.Windows.Forms.CheckBox()
        Me.CBQ3no = New System.Windows.Forms.CheckBox()
        Me.CBQ3yes = New System.Windows.Forms.CheckBox()
        Me.CBQ2no = New System.Windows.Forms.CheckBox()
        Me.CBQ2yes = New System.Windows.Forms.CheckBox()
        Me.CBQ1no = New System.Windows.Forms.CheckBox()
        Me.CBQ1yes = New System.Windows.Forms.CheckBox()
        Me.CBQ9no = New System.Windows.Forms.CheckBox()
        Me.CBQ9yes = New System.Windows.Forms.CheckBox()
        Me.CBQ10no = New System.Windows.Forms.CheckBox()
        Me.CBQ10yes = New System.Windows.Forms.CheckBox()
        Me.CBQ11no = New System.Windows.Forms.CheckBox()
        Me.CBQ11yes = New System.Windows.Forms.CheckBox()
        Me.CBQ12no = New System.Windows.Forms.CheckBox()
        Me.CBQ12yes = New System.Windows.Forms.CheckBox()
        Me.CBQ13no = New System.Windows.Forms.CheckBox()
        Me.CBQ13yes = New System.Windows.Forms.CheckBox()
        Me.CBQ14no = New System.Windows.Forms.CheckBox()
        Me.CBQ14yes = New System.Windows.Forms.CheckBox()
        Me.CBQ15no = New System.Windows.Forms.CheckBox()
        Me.CBQ15yes = New System.Windows.Forms.CheckBox()
        Me.CmdCheck = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(274, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Do you use the dog filter on snapchat?"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(12, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(391, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Have you ever sent nudes to someone you're not dating?"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(12, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(218, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Do you feel entitled to things?"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(12, 134)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(223, 25)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Do you brag about having sex?"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(12, 234)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(273, 25)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Have you lost your virginity before 16?"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(12, 209)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(214, 25)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Is your snapscore under 100k?"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(12, 159)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(283, 25)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Do you wear long clothes when it's cold?"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(12, 184)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(228, 25)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Do you flirt with people for fun?"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(12, 84)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(294, 25)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Do you cover unneeded amounts of 'skin'?"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(12, 109)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(401, 25)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Would or have you had sex for any reason other than love?"
        '
        'CBQ8no
        '
        Me.CBQ8no.AutoSize = True
        Me.CBQ8no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ8no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ8no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ8no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ8no.Location = New System.Drawing.Point(478, 186)
        Me.CBQ8no.Name = "CBQ8no"
        Me.CBQ8no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ8no.TabIndex = 21
        Me.CBQ8no.Text = "No"
        Me.CBQ8no.UseVisualStyleBackColor = True
        '
        'CBQ8yes
        '
        Me.CBQ8yes.AutoSize = True
        Me.CBQ8yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ8yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ8yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ8yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ8yes.Location = New System.Drawing.Point(424, 186)
        Me.CBQ8yes.Name = "CBQ8yes"
        Me.CBQ8yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ8yes.TabIndex = 20
        Me.CBQ8yes.Text = "Yes"
        Me.CBQ8yes.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(13, 362)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(392, 19)
        Me.Label11.TabIndex = 34
        Me.Label11.Text = "Have you dated someone twice or more after complainnig about them?"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(12, 334)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(198, 25)
        Me.Label12.TabIndex = 33
        Me.Label12.Text = "Do you own a push-up bra?"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(12, 259)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(323, 25)
        Me.Label13.TabIndex = 32
        Me.Label13.Text = "Would you only make out with your boyfriend?"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(12, 284)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(247, 25)
        Me.Label14.TabIndex = 31
        Me.Label14.Text = "Have you gone to victoria's secret?"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(12, 309)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(354, 25)
        Me.Label15.TabIndex = 30
        Me.Label15.Text = "Have you had less than 5 exs before the age of 15?"
        '
        'CmdClose
        '
        Me.CmdClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdClose.Font = New System.Drawing.Font("Papyrus", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CmdClose.Location = New System.Drawing.Point(424, 389)
        Me.CmdClose.Name = "CmdClose"
        Me.CmdClose.Size = New System.Drawing.Size(96, 34)
        Me.CmdClose.TabIndex = 45
        Me.CmdClose.Text = "Close"
        Me.CmdClose.UseVisualStyleBackColor = False
        '
        'CBQ7no
        '
        Me.CBQ7no.AutoSize = True
        Me.CBQ7no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ7no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ7no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ7no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ7no.Location = New System.Drawing.Point(478, 161)
        Me.CBQ7no.Name = "CBQ7no"
        Me.CBQ7no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ7no.TabIndex = 47
        Me.CBQ7no.Text = "No"
        Me.CBQ7no.UseVisualStyleBackColor = True
        '
        'CBQ7yes
        '
        Me.CBQ7yes.AutoSize = True
        Me.CBQ7yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ7yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ7yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ7yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ7yes.Location = New System.Drawing.Point(424, 161)
        Me.CBQ7yes.Name = "CBQ7yes"
        Me.CBQ7yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ7yes.TabIndex = 46
        Me.CBQ7yes.Text = "Yes"
        Me.CBQ7yes.UseVisualStyleBackColor = True
        '
        'CBQ6no
        '
        Me.CBQ6no.AutoSize = True
        Me.CBQ6no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ6no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ6no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ6no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ6no.Location = New System.Drawing.Point(478, 136)
        Me.CBQ6no.Name = "CBQ6no"
        Me.CBQ6no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ6no.TabIndex = 49
        Me.CBQ6no.Text = "No"
        Me.CBQ6no.UseVisualStyleBackColor = True
        '
        'CBQ6yes
        '
        Me.CBQ6yes.AutoSize = True
        Me.CBQ6yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ6yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ6yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ6yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ6yes.Location = New System.Drawing.Point(424, 136)
        Me.CBQ6yes.Name = "CBQ6yes"
        Me.CBQ6yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ6yes.TabIndex = 48
        Me.CBQ6yes.Text = "Yes"
        Me.CBQ6yes.UseVisualStyleBackColor = True
        '
        'CBQ5no
        '
        Me.CBQ5no.AutoSize = True
        Me.CBQ5no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ5no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ5no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ5no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ5no.Location = New System.Drawing.Point(478, 111)
        Me.CBQ5no.Name = "CBQ5no"
        Me.CBQ5no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ5no.TabIndex = 51
        Me.CBQ5no.Text = "No"
        Me.CBQ5no.UseVisualStyleBackColor = True
        '
        'CBQ5yes
        '
        Me.CBQ5yes.AutoSize = True
        Me.CBQ5yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ5yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ5yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ5yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ5yes.Location = New System.Drawing.Point(424, 111)
        Me.CBQ5yes.Name = "CBQ5yes"
        Me.CBQ5yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ5yes.TabIndex = 50
        Me.CBQ5yes.Text = "Yes"
        Me.CBQ5yes.UseVisualStyleBackColor = True
        '
        'CBQ4no
        '
        Me.CBQ4no.AutoSize = True
        Me.CBQ4no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ4no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ4no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ4no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ4no.Location = New System.Drawing.Point(478, 86)
        Me.CBQ4no.Name = "CBQ4no"
        Me.CBQ4no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ4no.TabIndex = 53
        Me.CBQ4no.Text = "No"
        Me.CBQ4no.UseVisualStyleBackColor = True
        '
        'CBQ4yes
        '
        Me.CBQ4yes.AutoSize = True
        Me.CBQ4yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ4yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ4yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ4yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ4yes.Location = New System.Drawing.Point(424, 86)
        Me.CBQ4yes.Name = "CBQ4yes"
        Me.CBQ4yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ4yes.TabIndex = 52
        Me.CBQ4yes.Text = "Yes"
        Me.CBQ4yes.UseVisualStyleBackColor = True
        '
        'CBQ3no
        '
        Me.CBQ3no.AutoSize = True
        Me.CBQ3no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ3no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ3no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ3no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ3no.Location = New System.Drawing.Point(478, 61)
        Me.CBQ3no.Name = "CBQ3no"
        Me.CBQ3no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ3no.TabIndex = 55
        Me.CBQ3no.Text = "No"
        Me.CBQ3no.UseVisualStyleBackColor = True
        '
        'CBQ3yes
        '
        Me.CBQ3yes.AutoSize = True
        Me.CBQ3yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ3yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ3yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ3yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ3yes.Location = New System.Drawing.Point(424, 61)
        Me.CBQ3yes.Name = "CBQ3yes"
        Me.CBQ3yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ3yes.TabIndex = 54
        Me.CBQ3yes.Text = "Yes"
        Me.CBQ3yes.UseVisualStyleBackColor = True
        '
        'CBQ2no
        '
        Me.CBQ2no.AutoSize = True
        Me.CBQ2no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ2no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ2no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ2no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ2no.Location = New System.Drawing.Point(478, 36)
        Me.CBQ2no.Name = "CBQ2no"
        Me.CBQ2no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ2no.TabIndex = 57
        Me.CBQ2no.Text = "No"
        Me.CBQ2no.UseVisualStyleBackColor = True
        '
        'CBQ2yes
        '
        Me.CBQ2yes.AutoSize = True
        Me.CBQ2yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ2yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ2yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ2yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ2yes.Location = New System.Drawing.Point(424, 36)
        Me.CBQ2yes.Name = "CBQ2yes"
        Me.CBQ2yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ2yes.TabIndex = 56
        Me.CBQ2yes.Text = "Yes"
        Me.CBQ2yes.UseVisualStyleBackColor = True
        '
        'CBQ1no
        '
        Me.CBQ1no.AutoSize = True
        Me.CBQ1no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ1no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ1no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ1no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ1no.Location = New System.Drawing.Point(478, 11)
        Me.CBQ1no.Name = "CBQ1no"
        Me.CBQ1no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ1no.TabIndex = 59
        Me.CBQ1no.Text = "No"
        Me.CBQ1no.UseVisualStyleBackColor = True
        '
        'CBQ1yes
        '
        Me.CBQ1yes.AutoSize = True
        Me.CBQ1yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ1yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ1yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ1yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ1yes.Location = New System.Drawing.Point(424, 11)
        Me.CBQ1yes.Name = "CBQ1yes"
        Me.CBQ1yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ1yes.TabIndex = 58
        Me.CBQ1yes.Text = "Yes"
        Me.CBQ1yes.UseVisualStyleBackColor = True
        '
        'CBQ9no
        '
        Me.CBQ9no.AutoSize = True
        Me.CBQ9no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ9no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ9no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ9no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ9no.Location = New System.Drawing.Point(478, 211)
        Me.CBQ9no.Name = "CBQ9no"
        Me.CBQ9no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ9no.TabIndex = 73
        Me.CBQ9no.Text = "No"
        Me.CBQ9no.UseVisualStyleBackColor = True
        '
        'CBQ9yes
        '
        Me.CBQ9yes.AutoSize = True
        Me.CBQ9yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ9yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ9yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ9yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ9yes.Location = New System.Drawing.Point(424, 211)
        Me.CBQ9yes.Name = "CBQ9yes"
        Me.CBQ9yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ9yes.TabIndex = 72
        Me.CBQ9yes.Text = "Yes"
        Me.CBQ9yes.UseVisualStyleBackColor = True
        '
        'CBQ10no
        '
        Me.CBQ10no.AutoSize = True
        Me.CBQ10no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ10no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ10no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ10no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ10no.Location = New System.Drawing.Point(478, 236)
        Me.CBQ10no.Name = "CBQ10no"
        Me.CBQ10no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ10no.TabIndex = 71
        Me.CBQ10no.Text = "No"
        Me.CBQ10no.UseVisualStyleBackColor = True
        '
        'CBQ10yes
        '
        Me.CBQ10yes.AutoSize = True
        Me.CBQ10yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ10yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ10yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ10yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ10yes.Location = New System.Drawing.Point(424, 236)
        Me.CBQ10yes.Name = "CBQ10yes"
        Me.CBQ10yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ10yes.TabIndex = 70
        Me.CBQ10yes.Text = "Yes"
        Me.CBQ10yes.UseVisualStyleBackColor = True
        '
        'CBQ11no
        '
        Me.CBQ11no.AutoSize = True
        Me.CBQ11no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ11no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ11no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ11no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ11no.Location = New System.Drawing.Point(478, 261)
        Me.CBQ11no.Name = "CBQ11no"
        Me.CBQ11no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ11no.TabIndex = 69
        Me.CBQ11no.Text = "No"
        Me.CBQ11no.UseVisualStyleBackColor = True
        '
        'CBQ11yes
        '
        Me.CBQ11yes.AutoSize = True
        Me.CBQ11yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ11yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ11yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ11yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ11yes.Location = New System.Drawing.Point(424, 261)
        Me.CBQ11yes.Name = "CBQ11yes"
        Me.CBQ11yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ11yes.TabIndex = 68
        Me.CBQ11yes.Text = "Yes"
        Me.CBQ11yes.UseVisualStyleBackColor = True
        '
        'CBQ12no
        '
        Me.CBQ12no.AutoSize = True
        Me.CBQ12no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ12no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ12no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ12no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ12no.Location = New System.Drawing.Point(478, 286)
        Me.CBQ12no.Name = "CBQ12no"
        Me.CBQ12no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ12no.TabIndex = 67
        Me.CBQ12no.Text = "No"
        Me.CBQ12no.UseVisualStyleBackColor = True
        '
        'CBQ12yes
        '
        Me.CBQ12yes.AutoSize = True
        Me.CBQ12yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ12yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ12yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ12yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ12yes.Location = New System.Drawing.Point(424, 286)
        Me.CBQ12yes.Name = "CBQ12yes"
        Me.CBQ12yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ12yes.TabIndex = 66
        Me.CBQ12yes.Text = "Yes"
        Me.CBQ12yes.UseVisualStyleBackColor = True
        '
        'CBQ13no
        '
        Me.CBQ13no.AutoSize = True
        Me.CBQ13no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ13no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ13no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ13no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ13no.Location = New System.Drawing.Point(478, 311)
        Me.CBQ13no.Name = "CBQ13no"
        Me.CBQ13no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ13no.TabIndex = 65
        Me.CBQ13no.Text = "No"
        Me.CBQ13no.UseVisualStyleBackColor = True
        '
        'CBQ13yes
        '
        Me.CBQ13yes.AutoSize = True
        Me.CBQ13yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ13yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ13yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ13yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ13yes.Location = New System.Drawing.Point(424, 311)
        Me.CBQ13yes.Name = "CBQ13yes"
        Me.CBQ13yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ13yes.TabIndex = 64
        Me.CBQ13yes.Text = "Yes"
        Me.CBQ13yes.UseVisualStyleBackColor = True
        '
        'CBQ14no
        '
        Me.CBQ14no.AutoSize = True
        Me.CBQ14no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ14no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ14no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ14no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ14no.Location = New System.Drawing.Point(478, 336)
        Me.CBQ14no.Name = "CBQ14no"
        Me.CBQ14no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ14no.TabIndex = 63
        Me.CBQ14no.Text = "No"
        Me.CBQ14no.UseVisualStyleBackColor = True
        '
        'CBQ14yes
        '
        Me.CBQ14yes.AutoSize = True
        Me.CBQ14yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ14yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ14yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ14yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ14yes.Location = New System.Drawing.Point(424, 336)
        Me.CBQ14yes.Name = "CBQ14yes"
        Me.CBQ14yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ14yes.TabIndex = 62
        Me.CBQ14yes.Text = "Yes"
        Me.CBQ14yes.UseVisualStyleBackColor = True
        '
        'CBQ15no
        '
        Me.CBQ15no.AutoSize = True
        Me.CBQ15no.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ15no.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ15no.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ15no.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ15no.Location = New System.Drawing.Point(478, 360)
        Me.CBQ15no.Name = "CBQ15no"
        Me.CBQ15no.Size = New System.Drawing.Size(44, 23)
        Me.CBQ15no.TabIndex = 61
        Me.CBQ15no.Text = "No"
        Me.CBQ15no.UseVisualStyleBackColor = True
        '
        'CBQ15yes
        '
        Me.CBQ15yes.AutoSize = True
        Me.CBQ15yes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CBQ15yes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBQ15yes.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CBQ15yes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CBQ15yes.Location = New System.Drawing.Point(424, 360)
        Me.CBQ15yes.Name = "CBQ15yes"
        Me.CBQ15yes.Size = New System.Drawing.Size(48, 23)
        Me.CBQ15yes.TabIndex = 60
        Me.CBQ15yes.Text = "Yes"
        Me.CBQ15yes.UseVisualStyleBackColor = True
        '
        'CmdCheck
        '
        Me.CmdCheck.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CmdCheck.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdCheck.ForeColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.CmdCheck.Location = New System.Drawing.Point(309, 389)
        Me.CmdCheck.Name = "CmdCheck"
        Me.CmdCheck.Size = New System.Drawing.Size(96, 34)
        Me.CmdCheck.TabIndex = 74
        Me.CmdCheck.Text = "Check "
        Me.CmdCheck.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 384)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(51, 50)
        Me.PictureBox1.TabIndex = 75
        Me.PictureBox1.TabStop = False
        '
        'FemaleTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(532, 432)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CmdCheck)
        Me.Controls.Add(Me.CBQ9no)
        Me.Controls.Add(Me.CBQ9yes)
        Me.Controls.Add(Me.CBQ10no)
        Me.Controls.Add(Me.CBQ10yes)
        Me.Controls.Add(Me.CBQ11no)
        Me.Controls.Add(Me.CBQ11yes)
        Me.Controls.Add(Me.CBQ12no)
        Me.Controls.Add(Me.CBQ12yes)
        Me.Controls.Add(Me.CBQ13no)
        Me.Controls.Add(Me.CBQ13yes)
        Me.Controls.Add(Me.CBQ14no)
        Me.Controls.Add(Me.CBQ14yes)
        Me.Controls.Add(Me.CBQ15no)
        Me.Controls.Add(Me.CBQ15yes)
        Me.Controls.Add(Me.CBQ1no)
        Me.Controls.Add(Me.CBQ1yes)
        Me.Controls.Add(Me.CBQ2no)
        Me.Controls.Add(Me.CBQ2yes)
        Me.Controls.Add(Me.CBQ3no)
        Me.Controls.Add(Me.CBQ3yes)
        Me.Controls.Add(Me.CBQ4no)
        Me.Controls.Add(Me.CBQ4yes)
        Me.Controls.Add(Me.CBQ5no)
        Me.Controls.Add(Me.CBQ5yes)
        Me.Controls.Add(Me.CBQ6no)
        Me.Controls.Add(Me.CBQ6yes)
        Me.Controls.Add(Me.CBQ7no)
        Me.Controls.Add(Me.CBQ7yes)
        Me.Controls.Add(Me.CmdClose)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.CBQ8no)
        Me.Controls.Add(Me.CBQ8yes)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FemaleTest"
        Me.Text = "Test"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents CBQ8no As CheckBox
    Friend WithEvents CBQ8yes As CheckBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents CmdClose As Button
    Friend WithEvents CBQ7no As CheckBox
    Friend WithEvents CBQ7yes As CheckBox
    Friend WithEvents CBQ6no As CheckBox
    Friend WithEvents CBQ6yes As CheckBox
    Friend WithEvents CBQ5no As CheckBox
    Friend WithEvents CBQ5yes As CheckBox
    Friend WithEvents CBQ4no As CheckBox
    Friend WithEvents CBQ4yes As CheckBox
    Friend WithEvents CBQ3no As CheckBox
    Friend WithEvents CBQ3yes As CheckBox
    Friend WithEvents CBQ2no As CheckBox
    Friend WithEvents CBQ2yes As CheckBox
    Friend WithEvents CBQ1no As CheckBox
    Friend WithEvents CBQ1yes As CheckBox
    Friend WithEvents CBQ9no As CheckBox
    Friend WithEvents CBQ9yes As CheckBox
    Friend WithEvents CBQ10no As CheckBox
    Friend WithEvents CBQ10yes As CheckBox
    Friend WithEvents CBQ11no As CheckBox
    Friend WithEvents CBQ11yes As CheckBox
    Friend WithEvents CBQ12no As CheckBox
    Friend WithEvents CBQ12yes As CheckBox
    Friend WithEvents CBQ13no As CheckBox
    Friend WithEvents CBQ13yes As CheckBox
    Friend WithEvents CBQ14no As CheckBox
    Friend WithEvents CBQ14yes As CheckBox
    Friend WithEvents CBQ15no As CheckBox
    Friend WithEvents CBQ15yes As CheckBox
    Friend WithEvents CmdCheck As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
